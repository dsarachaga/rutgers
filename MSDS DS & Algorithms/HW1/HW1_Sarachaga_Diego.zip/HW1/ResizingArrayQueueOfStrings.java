/*
 * author: Diego Sarachaga
 * NetID: ds1591
 * */

package HW1;

public class ResizingArrayQueueOfStrings<Item> {

	private Item[] queue; // queue array
	private int n; // number of elements on queue
	private int first, last; // index of the first and last item of the queue
	private int items; // how many items are in the array

	public ResizingArrayQueueOfStrings() {
		queue = (Item[]) new Object[2];
		n = 0;
		first = 0;
		last = 0;
		items = 0;
	}

	public boolean isEmpty() {
		return n == 0;
	}

	public int size() {
		return n;
	}

	public int items() {
		return items;
	}

	public void printQueue() {
		if (isEmpty()) {
			System.out.println("The queue is empty");
		} else {
			System.out.print("| ");
			for (int i = 0; i < n; i++) {
				System.out.print(queue[(first + i)] + " | ");
			}
			System.out.println("");
		}
	}

	public void resize(int capacity) {
		if (capacity >= n) {
			Item[] aux = (Item[]) new Object[capacity];
			for (int i = 0; i < n; i++) {
				aux[i] = queue[(first + i) % queue.length];
			}
			queue = aux;
			first = 0;
			last = n;
		}

	}

	public void enqueue(Item item) {
		if (n == queue.length)
			resize(2 * queue.length);
		queue[last++] = item;
		if (last == queue.length)
			last = 0;
		n++;
		items++;

	}

	public Item dequeue() {
		if (isEmpty()) {
			System.out.println("Queue is empty");
		}
		Item item = queue[first];
		queue[first] = null;
		n--;
		items--;
		first++;
		if (first == queue.length)
			first = 0;

		if (n > 0 && n == queue.length / 4)
			resize(queue.length / 2);
		return item;
	}
}
