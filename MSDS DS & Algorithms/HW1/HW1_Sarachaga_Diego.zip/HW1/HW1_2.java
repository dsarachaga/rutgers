/*
 * author: Diego Sarachaga
 * NetID: ds1591
 * */

package HW1;

import java.util.Scanner;

public class HW1_2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		String action = "";

		MagicSet set = new MagicSet(10);
		MagicSet otherSet = new MagicSet(10);

		while (!action.toUpperCase().equals("G")) {
			System.out.println("Please select the operation you want to perform:\n" + "A) Create new set\n"
					+ "B) Add a new value to the set\n" + "C) Delete a value from the set\n"
					+ "D) Check if a value is on the set\n" + "E) Union two sets\n" + "F) Print set\n" + "G) Exit");

			// get action
			action = scanner.next();

			switch (action.toUpperCase()) {

			case "A":
				System.out.println("Enter the size of the set.");
				if (set.isEmpty(set)) {
					set = new MagicSet(scanner.nextInt());
				} else {
					otherSet = new MagicSet(scanner.nextInt());
				}
				System.out.println("A new set has been created.");
				break;
			case "B":
				if (set.toString().equals("")) {
					System.out.println("There is no set. Please create a new one.");
				} else {
					System.out.println("In which set do you want to add a value. Enter 1 for set 1 or 2 for set 2:\n");
					int setNumber = scanner.nextInt(); 
					if (setNumber  == 1) {
						System.out.println("Please enter a value to the set 1:\n");
						set.add((Object) scanner.next());
					} else {
						if (setNumber  == 2) {
							System.out.println("Please enter a value to the set 2:\n");
							otherSet.add((Object) scanner.next());
						}
					}
				}
				break;
			case "C":
				if (set.toString().equals("")) {
					System.out.println("There is no item to delete. The set is empty.");
				} else {
					System.out.println("Enter de value you want to delete.");
					if (set.delete((Object) scanner.next()))
						System.out.println("The value has been deleted.");
					else
						System.out.println("The value is not in the set.");
				}
				break;
			case "D":
				System.out.println("Enter de value you want to check.");
				if (set.contains((Object) scanner.next())) {
					System.out.println("The value is in the set.");
				} else {
					System.out.println("The value is not in the set.");
				}
				break;
			case "E":
				MagicSet newSet = set.union(otherSet);
				System.out.println("The new set is:");
				newSet.printSet(newSet);
				break;
			case "F":
				System.out.println("The actual set 1 is:");
				set.printSet(set);
				System.out.println("The actual set 2 is:");
				otherSet.printSet(otherSet);
				break;
			case "G":
				System.out.println("Program has finished.\n");
				break;

			default:
				action.toUpperCase().equals("F");
			}
		}
	}
}
