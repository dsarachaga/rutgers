/*
 * author: Diego Sarachaga
 * NetID: ds1591
 * */

package HW1;

public class MagicSet {
	private Object[] set;
	private int next;

	public MagicSet(int size) {
		set = new Object[size];
		next = 0;
	}

	public MagicSet(MagicSet otherSet) {
		set = new Object[0];
		next = 0;
	}

	public void add(Object value) {
		if (!contains(value)) {
			Object[] aux = new Object[0];
			if (next == set.length) {
				aux = new Object[set.length * 2];

				for (int i = 0; i < next; i++) {
					aux[i] = set[i];
				}
				set = aux;
			}
			set[next] = value;
			next++;
		} else {
			System.out.println("The value is already in the set.");
		}
	}

	private int indexOf(Object target) {
		for (int i = 0; i < next; i++) {
			if (set[i].equals(target))
				return i;
		}
		return -1;
	}

	public Boolean contains(Object target) {
		return indexOf(target) != -1;
	}

	public Boolean delete(Object target) {
		int index = indexOf(target);
		if (indexOf(target) == -1)
			return false;
		set[index] = set[--next];
		return true;
	}

	public MagicSet union(MagicSet otherSet) {
		Object[] aux = set;
		for (int i = 0; i < otherSet.next; i++) {
			add(otherSet.set[i]);
		}
		MagicSet returnSet = new MagicSet(set.length);
		returnSet.set = set;
		returnSet.next = next;
		Object[] set = aux;
		return returnSet;
	}

	public String toString() {
		String s = set.toString();
		return "{ " + s.substring(1, s.length() - 1) + " }";
	}

	public Boolean isEmpty(MagicSet set) {
		if (set.next == 0)
			return true;
		else
			return false;
	}

	public void printSet(MagicSet set) {
		if (isEmpty(set)) {
			System.out.println("The set is empty");
		} else {
			System.out.print("| ");
			for (int i = 0; i < set.next; i++) {
				System.out.print(set.set[i] + " | ");
			}
			System.out.println("");
		}
	}
}