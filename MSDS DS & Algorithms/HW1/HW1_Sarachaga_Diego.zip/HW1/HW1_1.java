/*
 * author: Diego Sarachaga
 * NetID: ds1591
 * */

package HW1;

import java.util.Scanner;

public class HW1_1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ResizingArrayQueueOfStrings queue = new ResizingArrayQueueOfStrings();

		String action = "";
		while (!action.toUpperCase().equals("F")) {
			System.out.println("Please select the operation you want to perform:\n" 
					+ "A) Add a new item to the queue\n"
					+ "B) Remove an item from the queue\n" 
					+ "C) Check queue size\n" 
					+ "D) Check if queue is empty\n"
					+ "E) Print queue\n" 
					+ "F) Exit");

			// get action
			action = scanner.next();

			switch (action.toUpperCase()) {

			case "A":
				System.out.println("Please enter the item to enqueue:\n");
				queue.enqueue(scanner.next());
				break;
			case "B":
				if (queue.isEmpty()){
					System.out.println("The queue is empty. Please add a new item.");
				}
				else {
					String itemDequeue = queue.dequeue().toString();
					System.out.println("Item " + itemDequeue + " has been dequeue.\n");
				}
				break;
			case "C":
				System.out.println("The queue size is " + queue.size());
				break;
			case "D":
				if (queue.isEmpty())
					System.out.println("The queue is empty");
				else
					System.out.println("The queue has " + queue.items() + " item(s) and it's size is "+ queue.size());
			case "E":
				System.out.println("The actual queue is:"); 
				queue.printQueue();
				break;
			case "F":
				System.out.println("Program has finished.\n");
				break;

			default: action.toUpperCase().equals("F");
			}
		}

	}

}
