package HW4;

/*
 * @author: Diego Sarachaga
 * @netID: ds1591
 */

public class NonrecursiveBST<Key extends Comparable<Key>, Value> {
	private Node root;
	int size = 0;

	private class Node {
		private Key key; // sorted by key
		private Value val; // associated value
		private Node left, right; // left and right subtrees

		public Node(Key key, Value val) {
			this.key = key;
			this.val = val;
		}

		@Override
		public String toString() {
			return "[" + key + ", " + val + "]";
		}
	}

	public void put(Key key, Value val) {
		Node z = new Node(key, val);
		if (root == null) {
			root = z;
			size++;
			return;
		}

		Node parent = null, x = root;
		while (x != null) {
			parent = x;
			int cmp = key.compareTo(x.key);
			if (cmp < 0)
				x = x.left;
			else if (cmp > 0)
				x = x.right;
			else {
				x.val = val;
				return;
			}
		}
		int cmp = key.compareTo(parent.key);
		if (cmp < 0)
			parent.left = z;
		else
			parent.right = z;
		size++;
	}

	Value get(Key key) {
		Node x = root;
		while (x != null) {
			int cmp = key.compareTo(x.key);
			if (cmp < 0)
				x = x.left;
			else if (cmp > 0)
				x = x.right;
			else
				return x.val;
		}
		return null;
	}

	public int height() {
		return height(root);
	}

	private int height(Node root) {
		if (root == null)
			return 0;

		return 1 + Math.max(height(root.left), height(root.right));
	}

	public String toString() {
		return toString(root);
	}

	private String toString(Node root) {
		if (root == null)
			return "";

		return toString(root.left) + " " + root.key + " " + toString(root.right);
	}

	public int getSize() {
		return size;
	}

	public boolean validateTree() {

		/*
		 * The time complexity is O(n), while the space complexity is O(n) because of the array needed to keep the keys in order to 
		know if they were already visited.
		*/
		Node current, pre;
		int nodes = 0;
		int connectors = -1;
		boolean nonRepeated = true; 
		
		//I create these array to keep the keys and know when I have visited one more than once
		int [] keys = new int[size]; 
		int i = 0;
		
		//This is to check that if that there is no tree, so it is always valid
		if (root == null)
			return false;

		current = root;
		while (current != null) {
			if (current.left == null) {
				nonRepeated = true; 
				for (int j=0;j < keys.length;j++){
					if (keys[j] == (int) current.key)
						nonRepeated = false; 
				}
				if (nonRepeated){
					keys[i] = (int) current.key;
					i++;
					nodes++;
				}
				connectors++;
				current = current.right;
			} else {
				pre = current.left;
				while (pre.right != null && pre.right != current)
					pre = pre.right;

				if (pre.right == null) {
					pre.right = current;
					current = current.left;
				}
				else {
					pre.right = null;
					nonRepeated = true; 
					for (int j=0;j < keys.length;j++){
						if (keys[j] == (int) current.key)
							nonRepeated = false; 
					}
					if (nonRepeated){
						keys[i] = (int) current.key;
						i++;
						nodes++;
					}
					connectors++;
					current = current.right;
				}
			}
		} 
		//System.out.println("nodes " +nodes);
		//System.out.println("connectors " +connectors);
		
		//I check that the amount of nodes and connectors follow the rule nodes - 1 = connectors 
		return nodes - 1 == connectors;
	}

	public void connectMinMax() {
		Node maxValue = root;
		Node cur = root;

		while (maxValue.right != null) {
			maxValue = maxValue.right;
		}

		while (cur.left != null) {
			cur = cur.left;
		}
		cur.left = maxValue;
	}
}