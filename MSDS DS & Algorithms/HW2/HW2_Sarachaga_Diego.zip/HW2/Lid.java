package HW2;

public class Lid
{
	private int id;
	private int size;
	
	public Lid(int id, int size)
	{
		this.id = id;
		this.size = size;
	}
	
	public int fit(Jar j)
	{
		int cmp = size - j.getSize();
		if (cmp < 0) return -1;
		if (cmp > 0) return 1;
		return 0;
	}

	public int getSize()
	{
		return size;
	}
	
	@Override
	public String toString()
	{
		return "" + id + "." + size;
	}
}