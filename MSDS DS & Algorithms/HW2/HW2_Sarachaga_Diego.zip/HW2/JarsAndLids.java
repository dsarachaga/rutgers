package HW2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class JarsAndLids
{
	public static void main(String[] args) throws IOException
	{
		final int N = 2000000;
		Random rand = new Random();
		
		Integer [] a = new Integer[N];
		
		//Log file writes every action that is printed in the console. It is not attached because it is too heavy
		//File log = new File("//Users//dsarachaga//Google Drive//Rutgers//MSDS Data Structures & Algorithms//workspace//DS&A//HW2//log.txt");
		//Output file writes the most important actions to determine how well the algorithm has run.
		File output = new File("//Users//dsarachaga//Google Drive//Rutgers//MSDS Data Structures & Algorithms//workspace//DS&A//HW2//output.txt");
		//BufferedWriter writerLog = new BufferedWriter(new FileWriter(log,true));
		BufferedWriter writerOutput = new BufferedWriter(new FileWriter(output,true));

		
		for (int i=0; i<a.length; i++)
			a[i] = rand.nextInt(90)+10;
		
		ArrayList<Integer> b = new ArrayList<Integer>(Arrays.asList(a));
		Collections.shuffle(b);
		
		Lid [] lid = new Lid[a.length];
		Jar[] jar = new Jar[a.length];
		
		for (int i=0; i<a.length; i++)
		{
			lid[i] = new Lid(i, a[i]);
			jar[i] = new Jar(i, b.get(i));
		}
		
		System.out.println("Original List");
		//writerLog.append("Original List, N = "+N+"\n");
		writerOutput.append("Original List, N = "+N+"\n");
		System.out.println("LIDS:\t" + Arrays.toString(lid));
		//writerLog.append("LIDS:\t" + Arrays.toString(lid)+"\n");
		System.out.println("Jars:\t" + Arrays.toString(jar));
		//writerLog.append("Jars:\t" + Arrays.toString(jar)+"\n");
		
		System.out.println("\nMatching Lids and Jars");
		//writerLog.append("\nMatching Lids and Jars\n");
		
		long arrangeStart = System.currentTimeMillis();
		
		System.out.println("Start Arrange");
		//writerLog.append("Start Arrange\n");
		Arrange.arrange(lid, jar);
		
		long arrangeFinish = System.currentTimeMillis();
		System.out.println("Finish Arrange");
		//writerLog.append("Finish Arrange\n");
		
		System.out.println("Arrange Total time: " + (arrangeFinish-arrangeStart)/1000.0 + " s" );
		//writerLog.append("Arrange Total time: " + (arrangeFinish-arrangeStart)/1000.0 + " s" );
		writerOutput.append("Arrange Total time: " + (arrangeFinish-arrangeStart)/1000.0 + " s" );
		
		System.out.println("\nLids and Jars Match: " + lidsAndJarsMatch(lid, jar));
		//writerLog.append("\nLids and Jars Match: " + lidsAndJarsMatch(lid, jar)+"\n");
		writerOutput.append("\nLids and Jars Match: " + lidsAndJarsMatch(lid, jar)+"\n");
				
		System.out.println("\nMatching Lids and Jars");
		//writerLog.append("\nMatching Lids and Jars\n");
		System.out.println("LIDS:\t" + Arrays.toString(lid));
		//writerLog.append("LIDS:\t" + Arrays.toString(lid)+"\n");
		System.out.println("Jars:\t" + Arrays.toString(jar));
		//writerLog.append("Jars:\t" + Arrays.toString(jar)+"\n");
		
		long totalTime = System.currentTimeMillis();

		System.out.println("Total time: " + (totalTime-arrangeStart)/1000.0 + " s\n" );
		//writerLog.append("Total time: " + (totalTime-arrangeStart)/1000.0 + " s\n\n\n" );
		writerOutput.append("Total time: " + (totalTime-arrangeStart)/1000.0 + " s\n\n" );
		
		//writerLog.close();
		writerOutput.close();
	}
	
	public static boolean lidsAndJarsMatch(Lid [] lid, Jar [] jar)
	{
		for (int i=0; i<lid.length; i++)
			if (lid[i].fit(jar[i]) != 0)
				return false;
		return true;
	}
}