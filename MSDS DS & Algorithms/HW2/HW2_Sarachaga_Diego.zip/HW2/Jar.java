package HW2;

public class Jar
{
	private int id;
	private int size;
	
	public Jar(int id, int size)
	{
		this.id = id;
		this.size = size;
	}

	public int fit(Lid l)
	{
		int cmp = size - l.getSize();
		if (cmp < 0) return -1;
		if (cmp > 0) return 1;
		return 0;
	}

	public int getSize()
	{
		return size;
	}
	
	@Override
	public String toString()
	{
		return "" + id + "." + size;
	}
}