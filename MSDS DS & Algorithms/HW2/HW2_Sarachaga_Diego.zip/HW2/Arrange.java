package HW2;

public class Arrange
{
	
	//Method used: heapsort, because it does not need any extra space; it maintains the heap within the array to be sorted
	//it also guarantees N log N 
	
	public Arrange(Lid l, Jar j) 
	{
	}
	
	public static void arrange(Lid[] lid, Jar[] jar) {
		Heap heap = new Heap();
		heap.sort(lid);
		heap.sort(jar);
	}

}
